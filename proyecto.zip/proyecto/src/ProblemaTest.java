public class ProblemaTest {
    public static void main(String[] args) {
        String txt = "Crevillente";
        String cifrado = "";

        for (int i = 0; i<=txt.length()-1; i++){

        }
    }

    public static int indexValue(char ch){
        String str1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for (int i = 0; i<=str1.length()-1; i++){
            Character ch_str = str1.charAt(i);
            Character ch2 = ch;
            if (ch_str.equals(ch)){

            }

        }
    }
}
