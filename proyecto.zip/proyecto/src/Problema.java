import java.io.*;
import java.util.Scanner;


public class Problema {

    public static void main(String[] args) {

        BufferedReader br = null;
        BufferedWriter bw = null;

        try {

            br = new BufferedReader(new FileReader("mensaje.txt"));
            bw = new BufferedWriter(new FileWriter("mensaje_cifrado.txt"));

            String linea;

            /* Lectura y validación  de clave */


            while ((linea = br.readLine()) != null) {
                StringBuilder sb = new StringBuilder(linea.length());



                /*Lo sentimos, no hemos sabido plantear un algoritmo, hemos dado lo mejor de nosotros,
                esperamos que toda nuestra reputacion no resida en el resultado de este proyecto.
                 */



                bw.write(sb.toString()); /* Escribe la cadena de caracteres en el fichero*/
                bw.newLine(); /* escribe nueva línea en el fichero */

            }




        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null)
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            if (bw != null)
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }

    }

}


